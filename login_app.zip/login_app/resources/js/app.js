require('./bootstrap');
require('./index.blade');
